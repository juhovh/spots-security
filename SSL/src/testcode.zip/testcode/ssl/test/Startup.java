package ssl.test;

import java.io.InputStream;
import java.io.OutputStream;

import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import javax.microedition.io.HttpsConnection;
import javax.microedition.io.StreamConnection;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

import com.sun.midp.pki.CertStore;
import com.sun.midp.pki.X509Certificate;
import com.sun.midp.publickeystore.SpotPublicKeyStore;
import com.sun.midp.ssl.SSLStreamConnection;

public class Startup extends MIDlet {

    private static String HTTPS_URL = 
            "https://secure3.silverorange.com/rsstest/rss_with_ssl.xml";
    private static String HTTP_URL = 
           // "http://www.sun.com/";
            "http://labs.silverorange.com/local/solabs/rsstest/rss_plain.xml";
    //private static String TEST_URL = "https://127.0.0.1:4433/";
    
    public static void main(String[] args) {
	try {
	    new Startup().startApp();
	} catch (MIDletStateChangeException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
    }
    private void testHTTPS(String url) {
	try {
	    long starttime, endTime;
            
            System.out.println("Opening connection to: " + url);
            starttime = System.currentTimeMillis();
	    HttpsConnection connection =
		    (HttpsConnection) Connector.open(url);
	    /*HttpsConnection connection =
		    (HttpsConnection) Connector
			    .open("https://www.verisign.com/");*/
	    connection.setRequestProperty("Connection", "close");
	    InputStream in = connection.openInputStream();
            
            endTime = System.currentTimeMillis();
            System.out.println("Time for SSL handshake: "
		    + (endTime - starttime));
	    System.out.println("HTTPS connection:\n"
		    + "Cipher Suite: "
		    + connection.getSecurityInfo().getCipherSuite()
		    + "\n"
		    + "Protocol name: "
		    + connection.getSecurityInfo().getProtocolName()
		    + "\n"
		    + "Protocol version: "
		    + connection.getSecurityInfo().getProtocolVersion()
		    + "\n"
		    + "Server certificate: "
		    + connection.getSecurityInfo().getServerCertificate()
			    .getSubject());
            
	    StringBuffer buf = new StringBuffer();
	    int ch;
	    while ((ch = in.read()) > 0) {
		buf.append((char) ch);
	    }
            
            endTime = System.currentTimeMillis();
            System.out.println("Total time to retrieve page (incl handshake):" +
		    + (endTime - starttime));

            System.out.println(buf.toString());
            System.out.flush();

            in.close();
	    connection.close();
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    private void testHTTP(String url) {
        try {
	    long starttime, endTime;
            
            System.out.println("Opening connection to: " + url);
            starttime = System.currentTimeMillis();
	    HttpConnection connection =
                    (HttpConnection) Connector.open(url);
	    connection.setRequestProperty("Connection", "close");
	    InputStream in = connection.openInputStream();
            
            endTime = System.currentTimeMillis();
            System.out.println("Time for connection: "
		    + (endTime - starttime));
            
	    StringBuffer buf = new StringBuffer();
	    int ch;
	    while ((ch = in.read()) > 0) {
		buf.append((char) ch);
	    }
            
            endTime = System.currentTimeMillis();
            System.out.println("Total time to retrieve page (incl conn):" +
		    + (endTime - starttime));

            System.out.println(buf.toString());
            System.out.flush();

            in.close();
	    connection.close();
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    protected void startApp() throws MIDletStateChangeException {
	System.out.println("Hello, world");
	
	SpotPublicKeyStore ks = null;
	ks=SpotPublicKeyStore.getTrustedKeyStore();
	    if (ks==null) {
		System.out.println("No CA keystore  on spot. Exiting");
		try {
		    Thread.sleep(2000);
		} catch (InterruptedException e) {		 
		}
		System.exit(-1);		
	    }
	
	 
	System.out.println("CAs in the SPOT's keystore: ");
	for (int i = 0; i < ks.numberOfKeys(); i++) {
	    X509Certificate ca;
	    ca= SpotPublicKeyStore.createCertificate(ks.getKey(i));		 
	    System.out.println("CA"
		    + i
		    + ":"
		    + ca.getSubject());
	}

	// testHTTPS(HTTPS_URL);
        testHTTP(HTTP_URL);
    }

    protected void pauseApp() {
	// This will never be called by the Squawk VM
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	// Only called if startApp throws any exception other than
	// MIDletStateChangeException
    }
}

/**
 * This program illustrates the SSLStreamConnection API which allows advanced
 * features such as HTTPS proxy support, better control over handling of
 * certificate errors and the ability to get periodic feedback during the SSL
 * handshake.
 */
class SSLTest2 {
    // Replace these values with what makes sense for your environment
    //private static final String SERVER_HOST = "www.verisign.com";

    // private static final String SERVER_HOST = "online.ba-ca.com";
    // //Supports tls
     private static final String SERVER_HOST = "secure3.silverorange.com";

     private static final String RELATIVE_FILE_PATH = "/rsstest/rss_with_ssl.xml";

    private static final int SERVER_PORT = 443;

//    private static final String RELATIVE_FILE_PATH = "/index.html";

    private static final int MAX_PAGE_SIZE = 1500;

    public static void sslTest(CertStore sks) throws Exception {
	SSLTest2 ssltest = new SSLTest2();
	SSLStreamConnection sSock = null;
	InputStream in = null;
	OutputStream out = null;

	StreamConnection s = null;
	OutputStream o = null;
	InputStream i = null;

	//SpotPublicKeyStore sks = SpotPublicKeyStore.getTrustedKeyStore();

	// create a TCP connection
	System.out.println("SSLTest2: Initiating direct SSL handshake");

	StreamConnection t =
		(StreamConnection) Connector.open("socket://" + SERVER_HOST
			+ ":" + SERVER_PORT);

	// Create an SSL connection
	sSock =
		new SSLStreamConnection(SERVER_HOST, SERVER_PORT, t
			.openInputStream(), t.openOutputStream(), sks);
	t.close();

	out = sSock.openOutputStream();
	in = sSock.openInputStream();

	System.out.println("SSLTest2: Sending GET request to " + SERVER_HOST
		+ ":" + SERVER_PORT);

	// Send the GET request
	out.write(("GET " + RELATIVE_FILE_PATH + " HTTP/1.0\r\n").getBytes());
	out.write(("Host: " + SERVER_HOST + "\r\n").getBytes());
	out.write(("User-Agent: Mozilla/4.51 [en] "
		+ "(X11; U; SunOS 5.7 sun4u)\r\n\r\n").getBytes());

	System.out.println("SSLTest2: Ready to read response from "
		+ SERVER_HOST + ":" + SERVER_PORT);

	System.out.println("------------------------------------------");

	// Read the response
	byte[] buf = new byte[MAX_PAGE_SIZE];
	int tot = 0;
	int cnt = 0;
	while ((tot < MAX_PAGE_SIZE)
		&& (cnt = in.read(buf, tot, (buf.length - tot))) != -1) {
	    tot += cnt;
	}
	System.out.println(new String(buf, 0, tot));
	System.out.println("\n\n      [remaining page not shown]");
	System.out.println("\n------------------------------------------");
	System.out.println("SampleSSLApp: Read " + tot + " total bytes");
	System.out.println("SampleSSLApp: Done");
	System.out.println("SampleSSLApp: Closing SSL socket.");
	in.close();
	out.close();
	sSock.close();
	if (s != null) {
	    if (i != null)
		i.close();
	    if (o != null)
		o.close();
	    s.close();
	}
    }
    
}
