package ssl.test;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.Exception;
import java.lang.System;

import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

/**
 * This program illustrates the simplest SSL API. While this particular
 * API is simple and fits within the CLDC's Generic Connection framework,
 * it does not offer many of the features (such as HTTPS proxy
 * support, application control over certificate errors etc) found
 * in the SSLStreamConnection API.
 */
public class sslsocketTest {
    // The following URI is used to establish an SSL connection
    // with the host www.verisign.com at port 443. Any errors encountered
    // during the processing of the server's certificate chain will
    // result in a warning (the default behavior is to abort the connection)
    // and a detailed commentary of the SSL handshake as it proceeds will
    // be printed.
    private static final String URI = "sslsocket://www.verisign.com:443";

    // Replace the above URI with another if you wish. Make sure that
    // you have direct reachability to the host specified in the URI
    // (i.e. there are no intervening firewalls) because this API does
    // not support proxies.

    // We retrieve only the first MAX_SIZE bytes from the HTTPS server
    // running at the host and port in the URI
    private static final int MAX_SIZE = 1500;

    public static void main(String[] args) {
	StreamConnection sc;
	OutputStream out = null;
	InputStream in = null;
	byte[] buf = new byte[MAX_SIZE];
	try {
	    System.out.println("Opening URI: " + URI);

	    // Establish an SSL connection with the host/port
            // specified in the URI
	    sc = (StreamConnection) Connector.open(URI);
	    if (sc == null) {
		System.out.println("Null connection");
	    } else {
		out = sc.openOutputStream();

                // Send an HTTP GET request ...
		System.out.println("Sending GET request ...");
		out.write("GET / HTTP/1.0\r\n\r\n".getBytes());
		System.out.println("Awaiting reply ...");

                // Read the first MAX_SIZE bytes in the response 
		in = sc.openInputStream();
		int bytesRead = 0;
		int b = 0;
		while ((bytesRead < buf.length) && 
		       (b = in.read(buf, bytesRead, 
				    (buf.length - bytesRead))) != -1) {
		    bytesRead += b;
		}
		System.out.println("Read " + bytesRead + " bytes");

                // Print the first MAX_SIZE bytes in the response
		System.out.println("-------------------------------------");
		System.out.println(new String(buf, 0, bytesRead));
		System.out.println("-------------------------------------");
		out.close();
		in.close();
		sc.close();
	    }
	} catch (Exception e) {
	    System.out.println("Caught exception " + e.toString());
	}
    }
}
